<?php if( is_active_sidebar( 'learn-wp-sidebar-shop' ) ): ?>
	<?php dynamic_sidebar( 'learn-wp-sidebar-shop' ); ?>
<?php endif;