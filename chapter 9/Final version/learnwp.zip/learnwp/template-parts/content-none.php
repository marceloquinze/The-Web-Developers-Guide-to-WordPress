<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package LearnWP
 */

?>

<p><?php esc_html_e( 'Nothing to display', 'learnwp' ); ?></p>